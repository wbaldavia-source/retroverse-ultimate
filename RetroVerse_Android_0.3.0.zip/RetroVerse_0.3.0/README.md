# RetroVerse – Ultimate Emulator 0.3.0

Android-first frontend for personal retro-game libraries. Local files and user-supplied HTTPS URLs are supported in one library. No commercial ROMs or BIOS files are bundled.

## Systems in scope
Atari 2600, Atari 7800, NES, SNES, Master System, Mega Drive/Genesis, Game Boy, Game Boy Color, Game Boy Advance, Nintendo 64, PlayStation, Sega Saturn, Arcade/Neo Geo.

## Build Android APK
Requires Node.js 22, Java 21, Android SDK and Gradle tooling.

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

Or push this project to GitHub and run Actions > Build RetroVerse Android APK. The workflow uploads a debug APK artifact; it is not a Play Store release.

## Important limitations of this prototype
- The app maps every planned system to an EmulatorJS core, but compatibility and speed must be tested per device and per game.
- Saturn, N64, PS1 and some arcade titles can be demanding; a listed core does not guarantee full-speed emulation.
- Multi-file disc images (for example CUE/BIN sets), zipped arcade sets and BIOS variants need additional validation and may not boot yet.
- Local ROMs/BIOS are stored in IndexedDB in the WebView origin. Browser storage may be cleared by Android/app settings; export/backup is not implemented yet.
- Online games require a direct HTTPS file URL with suitable CORS/range support. A web page URL is not a ROM URL. Remote source discovery/catalogue verification and legal metadata are not implemented yet.
- EmulatorJS loads from its public stable CDN; internet is required for first load and core assets.
- This is a development prototype, not a tested release APK. Do not treat the full system list as certification of support.

## BIOS and legal use
Import only BIOS/firmware files you are legally entitled to use. RetroVerse does not distribute BIOS or copyrighted games. Online catalogue entries must point to authorized homebrew, public-domain, or user-owned content.
